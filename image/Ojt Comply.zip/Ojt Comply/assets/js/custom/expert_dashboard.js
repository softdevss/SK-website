import { execute } from './ajax_main.js';

$ = (typeof $ !== 'undefined') ? $ : {};
$.expert_dashboard = (typeof $.expert_dashboard !== 'undefined') ? $.expert_dashboard : {};

$.expert_dashboard = (function() {

    var __villain = {
        insertVillain: () => {
            $("#loading-background").fadeOut();
            $("#submitBtn").unbind("click").on("click", function(){
            $("#loading-background").fadeIn();
            var payload = {
                    "name" :$("#nameID").val(),
                    "email" : $("#emailID").val()
                }
                execute.post('Api_controllers/upsertVilain',JSON.stringify(payload)).done(function (result) {
                console.log(result)
                    if (result.status == "SUCCESS") {
                        $("#loading-background").fadeOut(3000);
                        __villain.villain()
                    } else {
                    console.log("failed")
                        
                    }
                })
            })
        },
        villain: () => {
            execute.get('Api_controllers/fetchAllVillain').done(function (result) {
            console.log(result);
            if ( $.fn.DataTable.isDataTable('#example') ) {
                $('#example').DataTable().destroy();
                $('#example tbody').empty();
                }
            if(result.status=="SUCCESS"){
                // var records = Object.values(result.payload);
                // var records = result.payload;
                // console.log(records)
                var items = result.payload;
                // console.log(items)
                var data = [];
                var i;
                for(i=0; i<items.length; i++){
                    // console.log(i)
                    var trc = $('<tr class=task_log_content '+result.payload[i].id+'>');

                trc.append($('<td class="row1">')
                    .append(result.payload[i].id));
                trc.append($('<td class="row2">')
                    .append(result.payload[i].name));
                trc.append($('<td class="row3">')
                    .append(result.payload[i].email));
                trc.append($('<td class="row4">')
                    .append('<a href="/case-view?villain_ID='+result.payload[i].id+'" class="viewDocument '+result.payload[i].id+'">Update</a>'));

                $('#tbody').append(trc);
                }

                $('#example').DataTable({
                    "ordering": false,
                    "bLengthChange": false,
                    'bFilter': false 
                });

                // $("#example").removeClass("hide");
            }
                // $("input[name='test']").click(function(){
                //     var radioValue = $("input[type='radio']:checked").val();
                //     console.log(radioValue)
                //         $("#search_results").addClass("hide");
                //         $("#error").addClass("hide");
                //         __searchCase.findResult(radioValue);
                // });

            })

        }
        // ,
        // findResult: (radioValue) => {
        //     // console.log(radioValue)
        //     var payload = {
        //         "record_status_id":radioValue,
        //         "uac" : $.cookie("uac"),
        //         "user_id" : $.cookie("user_id")
        //     }
        //     console.log(payload);

        //     execute.post('Docket/fetchByIdRecordStatus',JSON.stringify(payload)).done(function (result) {
        //         // console.log(result)
        //         if ( $.fn.DataTable.isDataTable('#search_results') ) {
        //             $('#search_results').DataTable().destroy();
        //             $('#search_results tbody').empty();
        //           }
        //         if(result.status=="SUCCESS"){
        //             // var records = Object.values(result.payload);
        //             // var records = result.payload;
        //             // console.log(records)
        //             var items = result.payload;
        //             // console.log(items)
        //             var data = [];
        //             var i;
        //             for(i=0; i<items.length; i++){
        //                 // console.log(i)
        //                 var trc = $('<tr class=task_log_content '+result.payload[i].RECORD_ID+'>');

        //             trc.append($('<td class="row1">')
        //                 .append(result.payload[i].status_name));
        //             trc.append($('<td class="row2">')
        //             .append(result.payload[i].RECORD_NAME));
        //             trc.append($('<td class="row3">')
        //             .append(result.payload[i].TRANSACTION_NUM));
        //             trc.append($('<td class="row4">')
        //                 .append('<a href="/case-view?record_id='+result.payload[i].RECORD_ID+'" class="viewDocument vd'+result.payload[i].RECORD_ID+'">Open</a>'));

        //             $('#tbody').append(trc);
        //             }

        //             $('#search_results').DataTable({
        //                 "ordering": false,
        //                 "bLengthChange": false,
        //                 'bFilter': false 
        //             });

        //             $("#search_results").removeClass("hide");
        //         }
        //         else{
        //             $("#search_documents small span").html("0");
        //             $("#search_results").addClass("hide");
        //             $("#error").removeClass("hide");
        //         }
        //     });
        // }

    };
    
    return {
        villain : __villain
    };
}());

 

