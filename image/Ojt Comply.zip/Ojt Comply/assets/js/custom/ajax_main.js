var execute = {
    host: "http://localhost/daily_time_record/",
    get: function(methodName){
			var d = $.Deferred();
			$.ajax({
				method: "POST",
				url: execute.host+methodName,
				dataType: "json"
			}).done(function (data, textStatus, jqXHR) {
				d.resolve(data)
			}).fail(function (jqXHR, textStatus, errorThrown, request) {
			console.error(jqXHR);
			console.error(textStatus);
			console.error(errorThrown);

			d.resolve({
				status: 'ERROR',
				message: request
			});

			});
			return d.promise();
    },
    post: (methodName, payload) => {
			var d = $.Deferred();
			$.ajax({
				method: "POST",
				url: execute.host+methodName,
				dataType: "json",
				data: payload
			}).done(function (data, textStatus, jqXHR) {
				d.resolve(data)
			}).fail(function (jqXHR, textStatus, errorThrown, request) {
			console.error(jqXHR);
			console.error(textStatus);
			console.error(errorThrown);

			d.resolve({
				status: 'ERROR',
				message: request
			});
			
			});
			return d.promise();
	},
	file: (methodName, payload) => {
		var d = $.Deferred();
		$.ajax({
				method: "POST",
				url: execute.host+methodName,
				dataType: "json",
				cache: false,
				processData: false,
				contentType: false,
				data: payload
		}).done(function (data, textStatus, jqXHR) {
				d.resolve(data);
		}).fail(function (jqXHR, textStatus, errorThrown) {
				console.log('---FAILED---');
				console.log(jqXHR);
				console.log(textStatus);
				console.log(errorThrown);
				console.log('---FAILED---');
				
				d.resolve({
						status : 'ERROR',
						message : errorThrown
				});
		});
		return d.promise();
	},
	audit: (USER_ID,EVENT_ACTION,EVENT_DESC) => {
		var payload = { 'USER_ID' : USER_ID, 'EVENT_ACTION' : EVENT_ACTION, 'EVENT_DESC' : EVENT_DESC, 'HOST_ALIAS' : window.location.origin};
		execute.post("Audit_trail/generateAudit",JSON.stringify(payload)).done(function(result){
			if(result.status === "SUCCESS"){
				// console.log(result)
            }else{
                // window.location.href= "/"
            }
        });
	},
	batchFile: (methodName, payload) => {
		var d = $.Deferred();
		$(".overlay-back").show();
		$(".loadDiv").show();
		var key = jsonObj.get('file_id');
		// console.log(jsonObj.get('file_id'));
		$.ajax({
			method: "POST",
			url: execute.host+methodName,
			dataType: "json",
			cache: false,
			processData: false,
			contentType: false,
			/*data: JSON.stringify(jsonObj)*/
			data: payload,
			xhr: function () {
				var xhr = new window.XMLHttpRequest();
				//Upload progress
				xhr.upload.addEventListener("progress", function (evt) {
					if (evt.lengthComputable) {
						var percentComplete = evt.loaded / evt.total;
						//Do something with upload progress
						var percent = Math.round((percentComplete) * 100);
						// console.log(percent);
						// $("#progress-bar-percentage").css('width', percent * 5);
						// $("#percentageUpload").html(percent + "%").css({
						// 	'text-align': 'center',
						// 	'padding-bottom': '300px'
						// });
					
						$(".batchPercentage" + key).html(percent + "%");
						$(".batchPercentage" + key).css({
							'font-size': "12px",
							'padding-left' : '8%'						
						});
						// $(".fa fa-2x indicator0 fa-check-circle success").css({
							
						// });
					}
				}, false);

				return xhr;
			},
		}).done(function (data, textStatus, jqXHR) {
			d.resolve(data);
		}).fail(function (jqXHR, textStatus, errorThrown) {
			console.log('---FAILED---');
			console.log(jqXHR);
			console.log(textStatus);
			console.log(errorThrown);
			console.log('---FAILED---');

			d.resolve({
				status: 'ERROR',
				message: errorThrown
			});
		});
		return d.promise();
	},
	singleFile: (methodName, payload) => {
		var d = $.Deferred();
		// var key = jsonObj.get('file_id');
		// console.log(jsonObj.get('file_id'));
		$.ajax({
			method: "POST",
			url: execute.host+methodName,
			dataType: "json",
			cache: false,
			processData: false,
			contentType: false,
			/*data: JSON.stringify(jsonObj)*/
			data: payload,
			xhr: function () {
				var xhr = new window.XMLHttpRequest();
				//Upload progress
				xhr.upload.addEventListener("progress", function (evt) {
					if (evt.lengthComputable) {
						var percentComplete = evt.loaded / evt.total;
						//Do something with upload progress
						var percent = Math.round((percentComplete) * 100);
						$("#progress-bar-percentage").css('width', percent * 5);
						$("#percentageUpload").html(percent + "%").css({
							'text-align': 'center',
							'padding-bottom': '300px'
						});
					}
				}, false);

				return xhr;
			},
		}).done(function (data, textStatus, jqXHR) {
			d.resolve(data);
		}).fail(function (jqXHR, textStatus, errorThrown) {
			console.log('---FAILED---');
			console.log(jqXHR);
			console.log(textStatus);
			console.log(errorThrown);
			console.log('---FAILED---');

			d.resolve({
				status: 'ERROR',
				message: errorThrown
			});
		});
		return d.promise();
	},
	// getUserDetailsByUserId: () => {

    //     var payload = {
    //         "user_id": $.cookie("user_id")
    //     }
    //     execute.post("ws_users/viewUserDetailsByUserID",JSON.stringify(payload)).done(function(result){
    //         // console.log(result)
    //         if(result.status === "SUCCESS"){
    //             $(".osg-username").text(result.payload.USER_DETAILS_FNAME + " " + result.payload.USER_DETAILS_LNAME);
    //         }else{
    //             // window.location.href= "/"
    //         }
    //     });
	// },
	unformatDate: (date) => {
		var newdate = new Date(date);
		var dd = ("0" + newdate.getDate()).slice(-2);
		var mm = ("0" + (newdate.getMonth() + 1)).slice(-2);
		var y = newdate.getFullYear();
		var expY = parseInt(y + 5);
		var hh = ("0" + newdate.getHours()).slice(-2);
		var h = hh%12;
		var A = (hh >= 12) ? 'PM' : 'AM';
		var min = ("0" + newdate.getMinutes()).slice(-2);
		var someFormattedDate = y+mm+dd;
		return someFormattedDate;
	}
	// autoload: () => {
	// 	execute.getUserDetailsByUserId();
	// }
}
// execute.autoload();
export { execute };
